require 'gui'

local window = gui.create_window()
window.title = "Text Box Demo"

local text_label = windows:add_label()
text_label.x = 5
text_label.y = 8
text_label.text = Eerste getal:

local text_box = window:add_text_box()
text_box.x = 20
text_box.y = 8
text_box.width = 150

klik = window:add_button()
klik.x = 8
klik.y = 40
klik.text = "Klik op mij"

function klik:on_click()
  
    local text_label = window:add_label()
    text_label.x = 180
    text_label.y = 180
    text_label.width = 150
    text_label.text = text_box.text
    
  end

gui.run()