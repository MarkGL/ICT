getal = 1
cijfer = 1
antwoord= 1

for i = 1, 10 do
print(getal + cijfer)
cijfer = cijfer + 1
antwoord = antwoord + 1
end
