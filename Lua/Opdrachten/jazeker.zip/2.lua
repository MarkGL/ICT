print("Wat is de code?")
answer = string.lower(io.read())
if answer == "simsalabim" then
  print("De deur gaat open!")
 else
   print("Fout, probeer het opnieuw")
end