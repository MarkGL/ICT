<?php
	require 'info.php';

$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
<?php
	header('Location:./home/index.php');
?>
